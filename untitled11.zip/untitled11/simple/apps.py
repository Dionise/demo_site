from django.apps import AppConfig


class SimpleConfig(AppConfig):
    name = 'simple'
