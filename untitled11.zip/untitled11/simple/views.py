from django.http import HttpResponse, Http404, HttpResponseRedirect, request, response
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import TemplateView, ListView

from .models import *
from django.shortcuts import get_object_or_404, render, redirect
from .forms import *
from django.contrib.auth.forms import UserCreationForm
from django.views.generic.edit import FormView, CreateView, DeleteView
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect, render


def next(request):
    pass
    return render(request, 'html/next.html')


def genaral_home(request):
    pass
    return render(request, 'html/genaeral_home.html')


def about(request):
    pass
    return render(request, 'html/about.html')


def sendmail(request):
    pass
    return render(request, 'html/sendmail.html')


def products(request):
    Prod = Product.objects.all()
    return render(request, 'html/products.html', {'Prod': Prod})


def product_detail(request, product_id):
    Detail = get_object_or_404(Product, id=product_id)
    Producta = Product.objects.all()
    return render(request, 'html/product_detail.html', {'Detail': Detail, 'produse': Producta})


def login_sucess(request):
    pass
    return render(request, 'html/login succes.html')


def feedback_form(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)

        if form.is_valid():
            form.save()
            return render(request, 'html/thanks.html')
    else:
        form = FeedbackForm()
    return render(request, 'html/sendfeedbak.html', {'form': form})


class MyRegisterFormView(FormView):
    form_class = UserCreationForm

    success_url = ""

    template_name = "html/register.html"


def form_valid(self, form):
    form.save()
    return super(MyRegisterFormView, self).form_valid(form)


def form_invalid(self, form):
    return super(MyRegisterFormView, self).form_invalid(form)


class LoginView(TemplateView):
    template_name = "html/login.html"

    def dispatch(self, request, *args, **kwargs):
        context = {}
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect(reverse("next"))
            else:
                context['error'] = " Something is wrong try again"
        return render(request, self.template_name, context)


class ProfilePage(TemplateView):
    template_name = "html/profile.html"


class LogoutView(View):
    def get(self, request):
        logout(request)
        return HttpResponseRedirect("/")


# Future work

#
# class WishCreate(CreateView):
#     model = Wish
#     form_class = WishForm
#     template_name = "html/wishcreate.html"
#     success_url = '/'
#
#     def form_valid(self, form_class):
#         obj = form_class.save(commit=False)
#         obj.customer = self.request.user
#         obj.save()
#         return HttpResponseRedirect(self.get_success_url())
#
#
# class WishDelete(DeleteView):
#     model = Wish
#     success_url = reverse_lazy('wish-list')
#
#
# class WishList(ListView):
#     model = Wish
#     success_url = reverse_lazy('wish-list')
#
#     def get_queryset(self):
#         return Wish.objects.filter(customer=self.request.user)
