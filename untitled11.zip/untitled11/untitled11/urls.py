from django.contrib import admin
from django.urls import path
from simple import views
from django.conf.urls import url
from django.contrib.auth.forms import UserCreationForm
from simple.views import *

from simple.views import MyRegisterFormView

urlpatterns = [
    path('', views.genaral_home, name='general_home'),
    path('about/', views.about, name='about'),
    path('admin/', admin.site.urls),
    path('products/', views.products, name='products'),
    path('login/', views.login_sucess, name='login_sucess'),
    path('products/<int:product_id>/', views.product_detail, name='product_detail'),
    path('sendfed/', views.feedback_form, name='feedback_form'),
    path('accounts/register/', MyRegisterFormView.as_view(), name="register"),
    path('accounts/login/', LoginView.as_view(), name="login"),
    path('accounts/login/ok/', views.next, name='next'),
    path('accounts/profile/', ProfilePage.as_view(), name="profile"),
    path('accounts/logout/', LogoutView.as_view(), name="logout"),
    # path('accounts/login/ok/wish/', WishCreate.as_view(),name="Wish"),
	# path(),






    # path('accounts/')

]
